import express from 'express'
import UserController from "./users/users-controller.js"
//import ArticlesController from "./controllers/articles/articles-controller.js";
import ArticlesController from "./articles/articles-controller.js";
import FollowsController from "./follows/follows-controller.js";
import RecommendsController from "./recommends/recommends-controller.js";

import AuthController from "./users/auth-controller.js";
import cors from 'cors'
import session from "express-session";
import mongoose from "mongoose";
const CONNECTION_STRING = 'mongodb+srv://mbrunkhorst219:mGCsboguLFqP4dQZ@cluster0.xwuxckj.mongodb.net/?retryWrites=true&w=majority' || 'mongodb://127.0.0.1:27017/articleer'

//mongoose.connect(CONNECTION_STRING);
mongoose.connect("mongodb://127.0.0.1:27017/project");
const app = express()
app.use(cors({
    credentials: true,
    origin: "http://localhost:3000",
  }
 ))
//  const sessionOptions = {
//     secret: "any string",
//     resave: false,
//     saveUninitialized: false,
//   };
//   app.use(
//     session(sessionOptions)
//   );
const sessionOptions = {
  secret: "any string",
  resave: false,
  saveUninitialized: false,
};
const temp = "notdevelopment";
if (temp !== "development") {
  sessionOptions.proxy = true;
  sessionOptions.cookie = {
    sameSite: "none",
    secure: true,
  };
}
app.use(session(sessionOptions));

  
app.use(express.json());
const port = process.env.PORT || 4000;
FollowsController(app);
RecommendsController(app);
ArticlesController(app);
UserController(app);
AuthController(app); 
app.listen(4000);
