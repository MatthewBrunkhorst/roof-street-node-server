import articlesModel from './articles-model.js';
export const findArticles  = ()          => articlesModel.find();
export const createArticle = (article)      => articlesModel.create(article);
export const deleteArticle = (tid)       => articlesModel.deleteOne({_id: tid});
export const updateArticle = (tid, article) => articlesModel.updateOne({_id: tid}, {$set: article})
export const findArticlesByStock = (stk) =>
  articlesModel.find({ stock: stk });