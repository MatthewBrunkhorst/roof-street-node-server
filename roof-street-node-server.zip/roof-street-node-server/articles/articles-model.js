import mongoose from 'mongoose';
import articlesSchema from './articles-schema.js'
const articlesModel = mongoose.model('PostModel', articlesSchema);
export default articlesModel;