import * as articlesDao from './articles-dao.js'

const findArticles = async (req, res) => {
   const articles = await articlesDao.findArticles()
   res.json(articles);
}



const createArticle = async (req, res) => {
  const newArticle = req.body;
  newArticle.likes = 0;
  newArticle.liked = false;
  const insertedArticle = await articlesDao.createArticle(newArticle);
  res.json(insertedArticle);
}



const deleteArticle = async (req, res) => {
  const articledIdToDelete = req.params.tid;
  const status = await articlesDao.deleteArticle(articledIdToDelete);
  res.json(status);
}




const updateArticle = async (req, res) => {
  const articledIdToUpdate = req.params.tid;
  const updates = req.body;
  const status = await articlesDao.updateArticle(articledIdToUpdate, updates);
  res.json(status);
}

const findArticlesByStock = async (req, res) => {
  const id = req.params.sid;
  const article = await articlesDao.findArticlesByStock(id);
  //req.session["viewedUser"] = user;
  res.json(article);
};


export default (app) => {
 app.post('/api/articles', createArticle);
 app.get('/api/articles', findArticles);
 app.put('/api/articles/:tid', updateArticle);
 app.delete('/api/articles/:tid', deleteArticle);
 app.get('/api/stocks/:sid', findArticlesByStock);
}
