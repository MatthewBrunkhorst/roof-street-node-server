import mongoose from 'mongoose';
const schema = mongoose.Schema({
  uid: String,
  userName: String,
  body: String,
  likes: Number,
  title: String,
  stock: String
}, {collection: 'articles'});
export default schema;