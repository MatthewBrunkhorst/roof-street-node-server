import * as followsDao from './follows-dao.js'

const findFollows = async (req, res) => {
   const follows = await followsDao.findFollows()
   res.json(follows);
}



const createFollow = async (req, res) => {
  const follow = await followsDao.findFollowByData(req.body.uid, req.body.stock);
  if (follow) {
    res.sendStatus(403);
    return;
  }
  const newFollow = await followsDao.createFollow(req.body);
  // req.session["currentUser"] = newUser;
  res.json(newFollow);
  // const newFollow = req.body;
  // const insertedFollow = await followsDao.createFollow(newFollow);
  // res.json(insertedFollow);
}




const deleteFollow = async (req, res) => {
  const followdIdToDelete = req.params.tid;
  const status = await followsDao.deleteFollow(followdIdToDelete);
  res.json(status);
}




const updateFollow = async (req, res) => {
  const followdIdToUpdate = req.params.tid;
  const updates = req.body;
  const status = await followsDao.updateFollow(followdIdToUpdate, updates);
  res.json(status);
}

const findFollowsByStock = async (req, res) => {
  const id = req.params.sid;
  const follow = await followsDao.findFollowsByStock(id);
  //req.session["viewedUser"] = user;
  res.json(follow);
};
const findFollowsByUser = async (req, res) => {
  const id = req.params.uid;
  const follow = await followsDao.findFollowsByUser(id);
  //req.session["viewedUser"] = user;
  res.json(follow);
};


export default (app) => {
 app.post('/api/follows', createFollow);
 app.get('/api/follows', findFollows);
 app.put('/api/follows/:tid', updateFollow);
 app.delete('/api/follows/:tid', deleteFollow);
 app.get('/api/stocks/follows/:sid', findFollowsByStock);
 app.get('/api/users/follows/:uid', findFollowsByUser);
}
