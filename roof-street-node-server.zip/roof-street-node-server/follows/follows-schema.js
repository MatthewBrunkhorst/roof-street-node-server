import mongoose from 'mongoose';
const schema = mongoose.Schema({
  uid: String,
  stock: String
}, {collection: 'follows'});
export default schema;