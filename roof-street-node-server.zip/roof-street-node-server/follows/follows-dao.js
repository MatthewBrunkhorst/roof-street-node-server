import followsModel from './follows-model.js';
export const findFollows  = ()          => followsModel.find();
export const createFollow = (follow)      => followsModel.create(follow);
export const deleteFollow = (tid)       => followsModel.deleteOne({_id: tid});
export const updateFollow = (tid, follow) => followsModel.updateOne({_id: tid}, {$set: follow})
export const findFollowsByStock = (stk) =>
  followsModel.find({ stock: stk });
export const findFollowsByUser = (usr) =>
  followsModel.find({ uid: usr });
export const findFollowByUID = (uid) =>
  followsModel.findOne({ uid });
export const findFollowByData = (uid, stock) =>
  followsModel.findOne({ uid, stock });