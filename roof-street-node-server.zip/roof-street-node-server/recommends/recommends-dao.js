import recommendsModel from './recommends-model.js';
export const findRecommends  = ()          => recommendsModel.find();
export const createRecommend = (recommend)      => recommendsModel.create(recommend);
export const deleteRecommend = (tid)       => recommendsModel.deleteOne({_id: tid});
export const updateRecommend = (tid, recommend) => recommendsModel.updateOne({_id: tid}, {$set: recommend})
export const findRecommendsByStock = (stk) =>
  recommendsModel.find({ stock: stk });
  export const findRecommendsByUser = (usr) =>
  recommendsModel.find({ uid: usr });
export const findRecommendByUID = (uid) =>
  recommendsModel.findOne({ uid });
  export const findRecommendByData = (uid, stock) =>
  recommendsModel.findOne({ uid, stock });