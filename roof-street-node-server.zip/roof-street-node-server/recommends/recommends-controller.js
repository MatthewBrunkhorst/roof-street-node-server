import * as recommendsDao from './recommends-dao.js'

const findRecommends = async (req, res) => {
   const recommends = await recommendsDao.findRecommends()
   res.json(recommends);
}



const createRecommend = async (req, res) => {
  const recommend = await recommendsDao.findRecommendByData(req.body.uid, req.body.stock);
  if (recommend) {
    res.sendStatus(403);
    return;
  }
  const newRecommend = await recommendsDao.createRecommend(req.body);
  // req.session["currentUser"] = newUser;
  res.json(newRecommend);
  // const newRecommend = req.body;
  // const insertedRecommend = await recommendsDao.createRecommend(newRecommend);
  // res.json(insertedRecommend);
}




const deleteRecommend = async (req, res) => {
  const recommenddIdToDelete = req.params.tid;
  const status = await recommendsDao.deleteRecommend(recommenddIdToDelete);
  res.json(status);
}




const updateRecommend = async (req, res) => {
  const recommenddIdToUpdate = req.params.tid;
  const updates = req.body;
  const status = await recommendsDao.updateRecommend(recommenddIdToUpdate, updates);
  res.json(status);
}

const findRecommendsByStock = async (req, res) => {
  const id = req.params.sid;
  const recommend = await recommendsDao.findRecommendsByStock(id);
  //req.session["viewedUser"] = user;
  res.json(recommend);
};

const findRecommendsByUser = async (req, res) => {
  const id = req.params.uid;
  const recommend = await recommendsDao.findRecommendsByUser(id);
  //req.session["viewedUser"] = user;
  res.json(recommend);
};


export default (app) => {
 app.post('/api/recommends', createRecommend);
 app.get('/api/recommends', findRecommends);
 app.put('/api/recommends/:tid', updateRecommend);
 app.delete('/api/recommends/:tid', deleteRecommend);
 app.get('/api/stocks/recommends/:sid', findRecommendsByStock);
 app.get('/api/users/recommends/:uid', findRecommendsByUser);
}
