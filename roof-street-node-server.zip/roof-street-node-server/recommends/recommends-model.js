import mongoose from 'mongoose';
import recommendsSchema from './recommends-schema.js'
const recommendsModel = mongoose.model('RecommendModel', recommendsSchema);
export default recommendsModel;